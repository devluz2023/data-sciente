data = open('data/data/ExecucaoFinanceira.csv', 'r')
for line in data:
    print(line)
data.close()
