def main():
    print("Olá")

if __name__ == "__main__":
    main()
