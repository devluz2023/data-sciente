with open('data/data/ExecucaoFinanceira.csv', 'r') as data:
    content = data.read()
    print(content)
