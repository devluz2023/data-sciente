def sum(a, b):
    return a + b

c = sum(1, 3)
