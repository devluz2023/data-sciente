# coding: utf-8

"Copa 2014"

'Copa do mundo 2014'

'''2014 - Copa do mundo
'''

"copa 'padrão fifa'"

'copa "padrão fifa"'
