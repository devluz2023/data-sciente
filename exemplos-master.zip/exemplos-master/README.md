# Exemplos do livro "Python - Escreva seus primeiros programas"

Fórum de discussão - `http://forum.casadocodigo.com.br/`

# Contato

```
felipecruz@gmail.com
```
