# coding: utf-8

print("""\
Uso: consulta_base [OPCOES]
     -h                        Exibe saída de ajuda
     -U url                    Url do dataset
""")

