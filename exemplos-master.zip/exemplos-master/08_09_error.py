import unittest

class DataTableTest(unittest.TestCase):
    def setUp(self):
        self.out_file = open()

    def test_add_column(self):
        pass

    def tearDown(self):
        print("tearDown")

