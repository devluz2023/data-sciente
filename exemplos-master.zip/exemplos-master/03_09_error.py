import math
math = 10
print(math.sqrt(9))
Traceback (most recent call last):
  File "03_09_error.py", line 3, in <module>
    print(math.sqrt(9))
AttributeError: 'int' object has no attribute 'sqrt'
