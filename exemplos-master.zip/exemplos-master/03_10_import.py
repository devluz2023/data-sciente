import math as matematica
print(matematica.sqrt(9))
