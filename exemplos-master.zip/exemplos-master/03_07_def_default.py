def salario_descontado_imposto(salario, imposto=27.):
    return salario - (salario * imposto * 0.01)
