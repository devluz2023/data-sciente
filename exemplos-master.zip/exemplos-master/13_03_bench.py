import sys

print(sum(10 for x in range(10000000)))
#print(sum([10 for x in range(100000000)]))
