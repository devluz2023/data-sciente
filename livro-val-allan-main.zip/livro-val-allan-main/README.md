Olá, pessoal!😀

Esse é o repositório do livro Séries temporais com Prophet. Análise e previsão de dados com Python. 🔮

Aqui temos os *datasets* utilizados nos capítulos e também temos uma pasta para cada capítulo contendo os seus respectivos códigos.

⚠️ Atualização importante: sempre que você for importar a biblioteca Prophet utilize
```from prophet``` ao invés de ```from fbprophet```. 
> Antes o nome do pacote era "fbprophet", mas a partir da versão
1.0, o nome do pacote mudou para "prophet".

Qualquer dúvida entre em contato conosco! 

<p align="left"><img src='https://media.giphy.com/media/E6jscXfv3AkWQ/giphy.gif'</p>
