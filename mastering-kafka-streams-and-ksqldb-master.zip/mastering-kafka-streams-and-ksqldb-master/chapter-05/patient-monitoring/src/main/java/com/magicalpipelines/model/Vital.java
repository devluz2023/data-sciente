package com.magicalpipelines.model;

public interface Vital {
  public String getTimestamp();
}
