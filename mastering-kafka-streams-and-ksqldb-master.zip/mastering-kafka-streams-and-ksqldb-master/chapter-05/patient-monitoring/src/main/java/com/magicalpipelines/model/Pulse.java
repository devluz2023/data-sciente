package com.magicalpipelines.model;

public class Pulse implements Vital {
  private String timestamp;

  public String getTimestamp() {
    return this.timestamp;
  }
}
