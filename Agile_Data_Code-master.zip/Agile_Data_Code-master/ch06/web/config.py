EMAILS_PER_PAGE=15
ELASTIC_URL='http://localhost:9200/inbox'