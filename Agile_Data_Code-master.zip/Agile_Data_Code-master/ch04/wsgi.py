import sys
sys.path.append('/home/dotcloud/current')
from index import app as application