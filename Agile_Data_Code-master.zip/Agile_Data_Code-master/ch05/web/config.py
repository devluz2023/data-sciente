EMAILS_PER_PAGE=16
ELASTIC_URL='http://localhost:9200/inbox'