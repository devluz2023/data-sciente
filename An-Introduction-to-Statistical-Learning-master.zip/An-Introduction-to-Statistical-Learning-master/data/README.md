This contains the datasets which are used in the book. 
To download, open the csv file, click on raw, and save it.
