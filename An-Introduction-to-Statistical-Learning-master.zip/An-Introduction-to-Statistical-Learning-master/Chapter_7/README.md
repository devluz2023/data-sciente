Some commenrs from my side - 
- In the lab's notebook, i used my_encoder for one hot encoding for categorical variables, Although in context of this lab, we don't need any other variables expcept age, but still
i am keeping the code for one hot encoding in case you might need the technique somewhere else. ITS NOT REQUIRED FOR ONE HOT ENCODING IN THIS LAB.
