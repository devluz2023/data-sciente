# Exemplos-Livro-Servicos-Cognitivos
Exemplos do meu livro de Serviços Cognitivos
