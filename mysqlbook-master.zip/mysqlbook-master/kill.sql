/*
*******************************************
*   Editora: Casa do Código               *
*   Livro..: MySQL do básico ao Avançado  *
*   ISBN...:                              *  
*   Autor..: Vinicius Carvalho de Souza   *
******************************************* 

Não esqueça de atribuir um valor antes para a variavel  @numero_id!!

set @numero_id = numero_id_sessao;
*/
 
kill @numero_id;