Repositório com os códigos e as bases de dados utilizados no livro: **Big Data - Técnicas e tecnologias para extração de valor dos dados**.

![alt tag](https://cdn.shopify.com/s/files/1/0155/7645/products/4MRnPs-gpoIYhwqavVoX2Mc64HktcIqFtQOyX8x0yDo_large.jpg?v=1480680976)

[**Comprar**](https://www.casadocodigo.com.br/products/livro-big-data)
