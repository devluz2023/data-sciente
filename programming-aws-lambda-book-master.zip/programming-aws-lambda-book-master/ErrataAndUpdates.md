# Programming AWS Lambda - Errata and Updates

## Chapter 3

### Invocation Types

On page 44 the example using `aws lambda invoke` also requires the argument `--cli-binary-format raw-in-base64-out` when using version 2 of the AWS CLI.