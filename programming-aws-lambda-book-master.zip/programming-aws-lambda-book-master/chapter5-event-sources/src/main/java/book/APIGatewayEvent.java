package book;

import java.util.Map;

public class APIGatewayEvent {
    public String path;
    public Map<String, String> queryStringParameters;
}
