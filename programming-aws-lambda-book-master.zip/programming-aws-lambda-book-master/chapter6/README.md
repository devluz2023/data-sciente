# Chapter 6

Example code for Chapter 6

For more details, see the chapter in the book.

If your integration tests fail (running `mvn verify`) then see the note in the chapter about explicitly setting the region in your `~/.aws/config` file under a section named `[profile-name]` or `[default]` if you're using the default AWS profile.
