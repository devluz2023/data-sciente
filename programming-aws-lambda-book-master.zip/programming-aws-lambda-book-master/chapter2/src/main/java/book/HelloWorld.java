package book;

public class HelloWorld {
    public String handler(String s) {
        return "Hello, " + s;
    }
}