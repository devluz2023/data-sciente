class LLMTwinException(Exception):
    pass


class ImproperlyConfigured(LLMTwinException):
    pass
