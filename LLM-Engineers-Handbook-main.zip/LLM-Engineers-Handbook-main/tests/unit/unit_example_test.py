def test_unit_example() -> None:
    string = "unit_test_example"

    assert string == "unit_test_example"
