def test_integration_example() -> None:
    string = "integration_test_example"

    assert string == "integration_test_example"
